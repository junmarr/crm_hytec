<?php
require_once("includes/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dealName = $_POST["dealName"];
    $dealValue = $_POST["dealValue"];
    $dealStage = $_POST["dealStage"];
    $dDate = $_POST["dDate"];
    $contactId = $_POST["id"];
    $dealID = $_POST["dealID"];

    $dDate = date("Y-m-d", strtotime($_POST["dDate"]));

    if (!empty($dealID)) {
        // Update operation
        $sql = "UPDATE deals SET dName = ?, dValue = ?, dStage = ?, datee = ? WHERE dealID = ?";
        $stmt = $con->prepare($sql);
        $stmt->execute([$dealName, $dealValue, $dealStage, $dDate, $dealID]);
        $status = "Data updated";
    } else {
        // Insert operation
        $sql = "INSERT INTO deals (dName, dValue, dStage, datee, contacts_ID) VALUES (?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->execute([$dealName, $dealValue, $dealStage, $dDate, $contactId]);
        $status = "Data added";
    }
    if ($stmt->rowCount() > 0) {
        header("Location: deals.php?id=" . $contactId . "&status=" . $status);
        exit();
    } else {
        header("Location: deals.php?status=error");
        exit();
    }
}
?>
