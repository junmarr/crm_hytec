<?php
require_once("includes/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['dealID'])) {
    $dealID = $_POST['dealID'];

    if (!empty($dealID)) {
        // Update isDeleted to 1 to indicate deletion
        $sql = "UPDATE deals SET isDeleted = 1 WHERE dealID = ?";
        $stmt = $con->prepare($sql);
        $stmt->execute([$dealID]);
        
        $status = "Deal deleted"; // Update status message if needed

        header("Location: deals.php?id=" . $contactID . "&status=" . $status);
        exit;
    }
}
?>