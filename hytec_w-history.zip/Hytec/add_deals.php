<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
require_once("includes/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dealName = $_POST["dealName"];
    $dealValue = $_POST["dealValue"];
    $dealStage = $_POST["dealStage"];
    $dDate = $_POST["dDate"];
    $contactId = $_POST["id"];
    $dealID = $_POST["dealID"];

    $dDate = date("Y-m-d", strtotime($_POST["dDate"]));
    $cont = $_POST["contacts"];
    $orders = $_POST["orders"];

    if (!empty($dealID)) {
        // Update operation
        $sql = "UPDATE deals SET dName = ?, dValue = ?, dStage = ?, datee = ?, contacts = ?, orders = ? WHERE dealID = ?";
        $stmt = $con->prepare($sql);
        $stmt->execute([$dealName, $dealValue, $dealStage, $dDate, $dealID]);
        $status = "Data updated";
    } else {
        // Insert operation
        $sql = "INSERT INTO deals (dName, dValue, dStage, datee, contacts_ID, contacts, orders) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->execute([$dealName, $dealValue, $dealStage, $dDate, $contactId, $cont, $orders]);
        $status = "Data added";
    }
    if ($stmt->rowCount() > 0) {
        header("Location: contact_details.php?id=" . $contactId . "&status=" . $status);
        exit();
    } else {
        header("Location: contact_details.php?status=error");
        exit();
    }
}
?>
